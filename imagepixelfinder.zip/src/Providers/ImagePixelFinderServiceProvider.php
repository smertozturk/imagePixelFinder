<?php

declare(strict_types=1);

namespace smertozturk\imagepixelfinder\Providers;

use Illuminate\Support\ServiceProvider;

final class ImagePixelFinderServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
